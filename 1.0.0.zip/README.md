Send a daily request to french nomad map to set your location
